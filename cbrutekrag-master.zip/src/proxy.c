#include "proxy.h"
#include <stdio.h>
#include <string.h>

int proxy_load_file(const char *filename, proxy_list_t *plist) {
    FILE *f = fopen(filename, "r");
    if (!f) return -1;

    plist->count = 0;
    plist->current = 0;

    while (fgets(plist->proxies[plist->count], sizeof(plist->proxies[0]), f)) {
        // strip newline
        size_t len = strlen(plist->proxies[plist->count]);
        if (len > 0 && (plist->proxies[plist->count][len-1] == '\n' || plist->proxies[plist->count][len-1] == '\r')) {
            plist->proxies[plist->count][len-1] = '\0';
        }
        if (strlen(plist->proxies[plist->count]) > 0) {
            plist->count++;
        }
        if (plist->count >= MAX_PROXIES) break;
    }
    fclose(f);

    return plist->count;
}

const char* proxy_next(proxy_list_t *plist) {
    if (plist->count == 0) return NULL;

    const char *p = plist->proxies[plist->current];
    plist->current = (plist->current + 1) % plist->count;  // round robin
    return p;
}
