#ifndef PROXY_H
#define PROXY_H

#define MAX_PROXIES 1024

typedef struct {
    char proxies[MAX_PROXIES][256];  // list of proxy URLs
    int count;                       // number of proxies loaded
    int current;                     // index of proxy in use
} proxy_list_t;

int proxy_load_file(const char *filename, proxy_list_t *plist);
const char* proxy_next(proxy_list_t *plist);

#endif
